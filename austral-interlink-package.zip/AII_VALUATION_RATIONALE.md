# VALUATION RATIONALE - AUSTRAL INTERLINK INTERNATIONAL

## VALUATION SUMMARY

| Approach | Multiple | SDE Base | Valuation |
|----------|----------|----------|-----------|
| Industry Standard | 2.0x - 2.5x | $80,000 | $160,000 - $200,000 |
| Distressed/Quick Sale | 1.0x - 1.5x | $80,000 | $80,000 - $120,000 |
| **Recommended Listing** | **1.0x - 1.2x** | $80,000 | **$75,000 - $95,000** |

## RATIONALE

### Positive Factors (Premium Justifiers)
1. **Client Database**: 995 clients with 467 active = genuine transferable asset
2. **Repeat Rate**: 53.6% indicates strong goodwill and relationships
3. **Regional Monopoly**: Fleurieu/Yorke runs have no viable competition
4. **Dry Cleaning Niche**: Premium positioning, not commoditised
5. **15-Year Trading History**: Established trust, especially with elderly clients

### Discount Factors (Reality Check)
1. **Key Man Risk**: Business entirely dependent on vendor relationships
2. **Forced Sale**: Health-driven urgency reduces negotiating power
3. **Age of Operator**: Some clients may not transition well
4. **No Employees**: Buyer starts solo with no backup
5. **Vehicle/Equipment**: May need near-term replacement

### COMPARABLE SALES (Australian Market)

- Cleaning route sales typically 1.0x - 2.5x SDE
- Franchise territories (Jim's, etc.) sell at 1.5x - 2.0x
- Non-franchise with strong book: 2.0x - 3.0x
- Distressed/urgent: 0.8x - 1.5x

### RECOMMENDED STRATEGY

1. **List at $95,000** (top of distressed range)
2. **Accept $75,000** minimum (1x current SDE)
3. **Highlight upside** - active operator could push to $130k+
4. **Speed is paramount** - first acceptable offer should close

### TERMS TO CONSIDER

- 20% deposit, balance on handover completion
- 2-week training/introduction period included
- 90-day support via phone/video
- Non-compete for vendor (standard)
