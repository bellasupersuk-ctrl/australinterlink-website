# DEEP RESEARCH BRIEF: TARGETED BUYER ENGAGEMENT PROTOCOL

## CLASSIFICATION: STRATEGIC SALES INTELLIGENCE
## OPERATION: PROJECT PHOENIX — PHASE II
## OBJECTIVE: Maximise Sale Velocity Through Buyer-Specific Engagement Strategies

---

## 1. MISSION PARAMETERS

### 1.1 Context
This research brief is the second phase of Project Phoenix — the strategic disposal of Austral Interlink International (AII), a 15-year carpet cleaning enterprise in South Australia. Phase I identified six high-probability buyers across three geographic segments. Phase II requires deep intelligence on each buyer to craft individualised engagement strategies that maximise both conversion probability and sale price within a 48-72 hour window.

### 1.2 Attached Assets
The following documents are attached and should be treated as primary source material:
- **PROJECT_PHOENIX_REPORT.docx** — Full strategic analysis and buyer identification
- **AII_ACTIVE_ALL.csv** — 467 active clients with service history
- **AII_FLEURIEU_PENINSULA.csv** — 84 clients in Fleurieu territory
- **AII_YORKE_PENINSULA.csv** — 24 clients in Yorke territory
- **AII_METRO_ADELAIDE.csv** — 328 clients in metropolitan Adelaide
- **AII_VIP_CLIENTS.csv** — 104 high-frequency clients (5+ services)

### 1.3 Research Objective
For each of the six identified buyers, produce a comprehensive intelligence dossier that enables the vendor (a 72-year-old master salesman with 40+ years of cold-calling experience) to execute a highly personalised, psychologically optimised sales approach within a single phone conversation.

---

## 2. THE ASSET BEING SOLD

### 2.1 Business Profile
- **Entity:** Austral Interlink International (AII)
- **Operator:** Sukninder "Suki" Singh (72, retiring due to health)
- **Trading History:** 15 years
- **Service:** Premium "Walk On Dry" carpet and upholstery cleaning
- **Annual Revenue:** $80,000 - $100,000 (reduced capacity)
- **Full Capacity Potential:** $120,000 - $150,000
- **Average Job Value:** $238

### 2.2 Client Base Metrics
- **Total Clients:** 995
- **Active Clients (2024-2025):** 467
- **Repeat Rate:** 53.6%
- **Platinum Tier (8+ jobs):** 25 clients
- **Gold Tier (5-7 jobs):** 85 clients
- **Silver Tier (3-4 jobs):** 190 clients

### 2.3 Geographic Segmentation

| Territory | Active Clients | Avg Job Value | Strategic Buyer |
|-----------|---------------|---------------|-----------------|
| Fleurieu Peninsula | 84 | $280+ | Jamie Simpson |
| Yorke Peninsula | 24 | $220 | Carolyn & Ian |
| Metro Adelaide | 328 | $210 | Max Wright / Jim's |

### 2.4 Key Selling Points
- 53.6% repeat rate (industry benchmark: 40%)
- Premium pricing power ($238 avg vs $120-$140 industry standard)
- Detailed service notes (pet protocols, stain history, access arrangements)
- "Walk On Dry" methodology — immediate room use, no 24hr drying time
- Exclusive regional runs with no viable competition
- Transferable trust — clients granted unaccompanied property access for years

---

## 3. BUYER INTELLIGENCE REQUIREMENTS

For each of the six identified buyers below, conduct comprehensive research and provide:

### 3.1 Business Intelligence
- Full business history, founding date, ownership structure
- Service offerings and pricing (if publicly available)
- Geographic coverage and route density
- Equipment profile (truck-mounted vs portable, brand affiliations)
- Online presence analysis (website quality, Google reviews, social media activity)
- Review sentiment analysis — what do customers praise/criticise?
- Any visible marketing spend or customer acquisition strategies
- Identifiable growth patterns or recent expansion

### 3.2 Competitive Position Analysis
- Market share estimate within their primary territory
- Identified competitors and competitive dynamics
- Recent market entries or exits in their territory
- Vulnerability assessment — where could a new entrant hurt them?
- Defensive acquisition motivation — would buying AII's book block a competitor?

### 3.3 Owner/Operator Psychographic Profile
- Professional background (if discoverable)
- Decision-making style indicators (fast/slow, analytical/intuitive)
- Communication preferences (phone, email, in-person)
- Values indicators (quality-focused, price-focused, relationship-focused)
- Likely objections based on business model and personality type
- Ego considerations — how to frame the pitch to appeal to their self-image

### 3.4 Financial Capacity Assessment
- Business scale indicators (fleet size, employee count, premises)
- Likely cash reserves or financing access
- Price sensitivity indicators
- Preferred deal structure (lump sum vs earn-out vs instalment)

### 3.5 Tailored Engagement Strategy
Based on the above research, provide:

**A. Opening Script (30-60 seconds)**
- Personalised opener referencing something specific about their business
- Hook that immediately establishes relevance and urgency
- Framing that appeals to their specific motivations

**B. Value Proposition Framing**
- Which aspects of the AII book matter most to this buyer?
- Specific client names/suburbs to mention that will resonate
- Revenue/margin language calibrated to their likely financial sophistication

**C. Objection Handling Matrix**
| Likely Objection | Root Cause | Response Strategy |
|-----------------|------------|-------------------|
| [Objection 1] | [Why they'd say this] | [Specific rebuttal] |
| [Objection 2] | [Why they'd say this] | [Specific rebuttal] |
| [Objection 3] | [Why they'd say this] | [Specific rebuttal] |

**D. Urgency Triggers**
- What would make this buyer move fast?
- Competitive fear angles (who else might buy this?)
- Opportunity cost framing (what do they lose by waiting?)

**E. Closing Technique**
- Recommended close style for this personality type
- Specific closing language
- Next-step proposal (NDA, meeting, deposit)

**F. Walk-Away Signal**
- Indicators that this buyer is not serious
- When to end the conversation and move to next target

---

## 4. TARGET BUYER DOSSIERS

### TARGET ALPHA: Jamie Simpson — Super Clean Carpet Care

**Known Intelligence:**
- **Business:** Super Clean Carpet Care
- **Location:** 12 Dolphin Ave, Encounter Bay (Victor Harbor area)
- **Territory:** Victor Harbor, Goolwa, Encounter Bay — Southern Fleurieu
- **Phone:** 0488 522 520
- **Email:** jamie@supercleancarpetcare.com.au (inferred)
- **Website:** superccc.com.au

**Research Requirements:**
1. How long has Super Clean operated? What is Jamie's background?
2. What is his current service coverage — does he already service Goolwa, Strathalbyn, Normanville?
3. What equipment does he run? Truck-mounted or portable?
4. What are his Google reviews like? What do customers value about his service?
5. Does he have employees or is he a sole operator?
6. Is there any indication of recent expansion or growth ambitions?
7. Who are his direct competitors in the Fleurieu? How does he differentiate?
8. What is his likely capacity — is he at full utilisation or hungry for more work?

**Strategic Context:**
AII's Fleurieu book contains 84 active clients including high-value accounts like Mrs Blanchard ($373 avg), Colleen Mccalum ($173 avg), and dense clusters in Victor Harbor and Goolwa. If Jamie doesn't acquire this book, a competitor could establish a beachhead in his territory.

**Deliverable:** Complete dossier per Section 3 specifications, with emphasis on defensive acquisition psychology and territory protection framing.

---

### TARGET BRAVO: Carolyn & Ian — Yorke Peninsula Carpet Cleaning

**Known Intelligence:**
- **Business:** Yorke Peninsula Carpet Cleaning
- **Location:** Kadina
- **Territory:** Kadina, Moonta, Wallaroo — entire Yorke Peninsula
- **Phone:** 0428 858 759
- **Email:** ypcarpet@gmail.com
- **Website:** ypcarpet.com.au

**Research Requirements:**
1. How long have Carolyn and Ian operated this business?
2. What is their service model — do they cover the whole peninsula or focus on Copper Coast?
3. Do they currently service Maitland, Crystal Brook, or the eastern Yorke Peninsula?
4. What equipment do they run? Any specialisations?
5. What is their Google review profile? What do customers say?
6. Are they a husband-wife team only, or do they have employees?
7. What is the competitive landscape on the Yorke Peninsula — are there other operators?
8. Is there any indication of their capacity utilisation or growth appetite?

**Strategic Context:**
AII's Yorke Peninsula run includes 24 clients in Maitland, Crystal Brook, and surrounding areas — territory that is 150km+ from Adelaide and logistically unviable for any metro buyer. Carolyn and Ian are the only logical acquirers. This is a monopoly consolidation opportunity for them.

**Deliverable:** Complete dossier per Section 3 specifications, with emphasis on monopoly economics and "pure profit" framing for existing route add-on.

---

### TARGET CHARLIE: Alex Oakley — NYP Cleaning Service

**Known Intelligence:**
- **Business:** Northern Yorke Peninsula Cleaning Service (NYP)
- **Location:** Moonta Bay
- **Ownership:** Oakley family (established 1983, currently run by Alex)
- **Phone:** 0417 808 512
- **Email:** nypcleaning@outlook.com.au
- **Website:** nypcleaning.com

**Research Requirements:**
1. What is the full history of NYP Cleaning? Third-generation family business?
2. What services do they offer beyond carpet cleaning? (Noted: general cleaning, lawn mowing)
3. What is their current carpet cleaning capability — is it a core service or peripheral?
4. What is their geographic coverage compared to Yorke Peninsula Carpet Cleaning?
5. Is Alex the owner-operator or does he manage a team?
6. What is their online presence and reputation?
7. What is the competitive dynamic between NYP and Yorke Peninsula CC?
8. Would they be interested in acquiring carpet-specific clients to cross-sell other services?

**Strategic Context:**
NYP is a backup buyer for the Yorke Peninsula book if Carolyn & Ian pass. However, they may also be used as leverage — mentioning NYP's interest to Carolyn could accelerate her decision.

**Deliverable:** Complete dossier per Section 3 specifications, with emphasis on cross-selling potential and family business succession psychology.

---

### TARGET DELTA: Bill Cobanoglu — Jim's Cleaning Group SA

**Known Intelligence:**
- **Role:** Regional Franchisor — Jim's Cleaning Group (South Australia)
- **Phone:** 131 546 (national line, request Bill Cobanoglu) or 0800 454 654
- **Email:** bill@jimslaundryservices.com.au
- **Structure:** Franchise model — Bill sells territories and recruits franchisees

**Research Requirements:**
1. What is Bill's specific role within the Jim's Group structure? How long has he held it?
2. How many Jim's Cleaning franchisees operate in South Australia, specifically Southern Adelaide?
3. What does a Jim's Cleaning franchise territory typically look like? How are they defined?
4. What does Jim's Group charge for franchise territories? What do franchisees pay for "work"?
5. Is there a Jim's Carpet Cleaning specifically, or is it under the general Jim's Cleaning banner?
6. What is Jim's Group's acquisition history — do they buy client books to seed new territories?
7. Who are the decision-makers for territory purchases — Bill locally, or head office approval required?
8. What is the typical transaction speed for Jim's Group — can they settle within 48 hours?
9. Are there any Jim's franchisees specifically in Happy Valley, Pasadena, or Morphett Vale?

**Strategic Context:**
The metro Adelaide book (328 clients) is ideal for splitting among multiple Jim's franchisees or seeding a new franchise territory. Bill doesn't clean carpets — he needs "work" to sell territories. AII's book is a ready-made income stream for his recruitment pipeline.

**Deliverable:** Complete dossier per Section 3 specifications, with emphasis on franchise economics, territory seeding value, and corporate decision-making speed.

---

### TARGET ECHO: Max Wright — The Carpet Doctor

**Known Intelligence:**
- **Business:** The Carpet Doctor
- **Location:** Blackwood (Adelaide foothills)
- **Territory:** Blackwood, Belair, Pasadena — Southern Adelaide hills
- **Phone:** 0409 692 003
- **Email:** max@thecarpetdoctor.com.au
- **Website:** thecarpetdoctor.com.au

**Research Requirements:**
1. How long has The Carpet Doctor operated? What is Max's professional background?
2. What is his exact service coverage — which suburbs does he currently service?
3. What equipment does he run? What is his service differentiation?
4. What are his Google reviews like? What do customers praise?
5. Is he a sole operator or does he have staff?
6. What is his current capacity utilisation — is he booked out or looking for work?
7. Who are his direct competitors in the Adelaide hills corridor?
8. Is there any indication of growth ambitions or prior acquisitions?

**Strategic Context:**
AII has strong client density in Blackwood, Belair, and Pasadena — exactly Max's territory. Acquiring these clients would add immediate density to his existing routes with zero additional travel time. This is an efficiency play.

**Deliverable:** Complete dossier per Section 3 specifications, with emphasis on route density economics and operational efficiency framing.

---

### TARGET FOXTROT: Murray Lands Cleaning Service

**Known Intelligence:**
- **Business:** Murray Lands Cleaning Service
- **Location:** Murray Bridge
- **Established:** 1982
- **Phone:** (08) 8532 6766
- **Email:** tdhaywood@bigpond.com
- **Profile:** Family-owned, accredited and insured

**Research Requirements:**
1. What is the ownership structure? Who is the current owner/operator (T.D. Haywood?)?
2. What services do they offer — carpet cleaning specifically, or general cleaning?
3. What is their geographic coverage — Murray Bridge only, or wider Murraylands?
4. What is their reputation and online presence?
5. Are they actively growing or in a maintenance/succession phase?
6. What is their capacity and appetite for acquisition?

**Strategic Context:**
AII has a small cluster of 3 clients in Murray Bridge. This is a low-priority "tuck-in" opportunity — worth a call but not a primary focus. May be used as a "whole book" fallback if regional splits fail.

**Deliverable:** Abbreviated dossier focusing on acquisition appetite and capacity assessment.

---

## 5. STRATEGIC OUTPUT REQUIREMENTS

### 5.1 Priority-Ranked Engagement Sequence
Based on research findings, provide a recommended call sequence with rationale:

| Priority | Target | Rationale | Optimal Call Time |
|----------|--------|-----------|-------------------|
| 1 | [Name] | [Why first] | [When to call] |
| 2 | [Name] | [Why second] | [When to call] |
| ... | ... | ... | ... |

### 5.2 Cross-Target Leverage Strategies
Identify opportunities to use interest from one buyer to accelerate decisions from another:
- Which buyers are natural competitors whose interest creates urgency for others?
- How to reference other interest without revealing specific terms?
- "Dutch auction" dynamics — when and how to deploy them?

### 5.3 Split vs Whole Decision Framework
Provide a decision tree for the vendor:
- At what price point should a "whole book" offer be accepted over pursuing the split?
- What combination of split offers equals or exceeds the whole book value?
- Time-value considerations — when does speed justify a discount?

### 5.4 Contingency Protocols
If primary targets decline:
- Second-tier buyer identification (research additional operators in each territory)
- Platform listing optimisation (Gumtree, Seek Business, Facebook groups)
- Broker engagement strategy (which Adelaide brokers handle service businesses?)

---

## 6. DELIVERABLE FORMAT

### 6.1 Structure
Produce a single comprehensive document with the following sections:
1. Executive Summary (1 page)
2. Engagement Sequence Recommendation (1 page)
3. Individual Buyer Dossiers (2-3 pages each, 6 buyers)
4. Cross-Target Leverage Strategies (1 page)
5. Contingency Protocols (1 page)
6. Appendix: Full Scripts by Buyer (1 page each)

### 6.2 Script Formatting
All scripts should be written in natural spoken English suitable for a 72-year-old Australian male with a warm, confident sales personality. Avoid:
- Corporate jargon
- Overly formal language
- American idioms
- Scripts that sound "scripted"

The vendor is a master salesman. The scripts should be conversation starters and talking points, not rigid word-for-word mandates.

### 6.3 Actionability Standard
Every output should pass the "8am Monday test" — if the vendor reads this document at 8am, can he pick up the phone at 8:01am and execute without additional research or preparation?

---

## 7. RESEARCH PARAMETERS

### 7.1 Source Hierarchy
1. **Official business websites** — primary source for service offerings, territory, contact details
2. **Google Business Profiles** — reviews, photos, posted updates, Q&A
3. **Yellow Pages / True Local / Yelp** — business listings, service categorisation
4. **Facebook business pages** — personality indicators, community engagement
5. **LinkedIn** — owner professional background (if available)
6. **ASIC / ABN Lookup** — business registration details, entity structure
7. **Industry directories** — Carpet Cleaning Association memberships, accreditations
8. **Local news / press** — any coverage of the business or owner
9. **Competitor analysis** — what do competitors say/do that reveals market dynamics?

### 7.2 Inference Standards
Where direct information is unavailable, clearly mark inferences as such:
- **Confirmed:** Directly sourced from reliable public record
- **Inferred:** Logical deduction from available evidence
- **Speculative:** Reasonable assumption requiring verification

### 7.3 Recency Requirement
All business contact details must be verified against current public listings. Flag any details that appear outdated (e.g., disconnected numbers, closed businesses).

---

## 8. SUCCESS CRITERIA

This research brief will be considered successful if:

1. **Completeness:** All six buyer dossiers are delivered with no significant intelligence gaps
2. **Actionability:** The vendor can execute calls immediately upon reading
3. **Specificity:** Each buyer's dossier feels personalised, not generic
4. **Strategic Depth:** The cross-leverage and contingency sections provide genuine tactical advantage
5. **Accuracy:** All contact details are verified and current
6. **Tone Calibration:** Scripts match the vendor's personality and Australian business culture

---

## 9. URGENCY CONTEXT

The vendor has recently undergone brain surgery and requires immediate medical retirement. Each day of delay:
- Risks client attrition as regular service schedules are missed
- Increases buyer perception of distressed sale, reducing price leverage
- Depletes the vendor's limited energy reserves for sales execution

This research must be returned within hours, not days. Prioritise speed and actionability over comprehensiveness. A good-enough dossier today beats a perfect dossier next week.

---

## 10. INITIATION COMMAND

Begin systematic research on all six targets in parallel. Prioritise:
1. **Contact verification** — confirm all phone numbers and emails are current
2. **Competitive positioning** — understand each buyer's market situation
3. **Psychological profiling** — identify decision-making style and motivations
4. **Script development** — craft personalised openers and objection handlers

The clock is running. Execute with precision.

---

**END BRIEF**

---

## APPENDIX A: QUICK REFERENCE — BUYER CONTACT DETAILS

| Target | Business | Owner | Phone | Email |
|--------|----------|-------|-------|-------|
| ALPHA | Super Clean Carpet Care | Jamie Simpson | 0488 522 520 | jamie@supercleancarpetcare.com.au |
| BRAVO | Yorke Peninsula CC | Carolyn & Ian | 0428 858 759 | ypcarpet@gmail.com |
| CHARLIE | NYP Cleaning Service | Alex Oakley | 0417 808 512 | nypcleaning@outlook.com.au |
| DELTA | Jim's Cleaning Group SA | Bill Cobanoglu | 131 546 | bill@jimslaundryservices.com.au |
| ECHO | The Carpet Doctor | Max Wright | 0409 692 003 | max@thecarpetdoctor.com.au |
| FOXTROT | Murray Lands Cleaning | T.D. Haywood | (08) 8532 6766 | tdhaywood@bigpond.com |

## APPENDIX B: ASSET VALUE SUMMARY

| Territory | Clients | Est. Value | Target Buyer |
|-----------|---------|------------|--------------|
| Fleurieu Peninsula | 84 | $40,000 - $50,000 | Jamie Simpson |
| Yorke Peninsula | 24 | $20,000 - $30,000 | Carolyn & Ian |
| Metro Adelaide | 328 | $25,000 - $35,000 | Max Wright / Jim's |
| **TOTAL** | **436** | **$85,000 - $115,000** | Split sale |
| **Whole Book Alternative** | 467 | $75,000 - $85,000 | Single buyer |

## APPENDIX C: VENDOR PROFILE (For Script Calibration)

**Name:** Sukninder "Suki" Singh
**Age:** 72
**Background:**
- 1984 Malaysian Olympic Field Hockey team (Los Angeles Games)
- Former Wine Estate Manager (Golden Grape Estate, Adelaide)
- Master cold-caller and sales trainer — trained rooms of telemarketers
- Built AII from scratch through weekend cold-calling over 15 years
- Known for: warm personality, instant rapport, encyclopaedic knowledge of Adelaide postcodes
- Sales style: Positive, laughing, never affected by rejection, straight into the next dial

**Script Calibration Notes:**
- Speaks naturally, warmly, with confidence
- Uses humour and charm instinctively
- Prefers conversation over script
- Needs talking points and key phrases, not word-for-word mandates
- Will adapt on the fly based on buyer's energy
- Australian vernacular, not American corporate speak
