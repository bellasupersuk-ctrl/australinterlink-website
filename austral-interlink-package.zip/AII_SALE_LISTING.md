# CARPET CLEANING BUSINESS FOR SALE - ADELAIDE & REGIONAL SA

## AUSTRAL INTERLINK INTERNATIONAL
**15-Year Established Premium Dry Carpet Cleaning Operation**

---

### ASKING PRICE: $75,000 - $95,000 (Walk In Walk Out)

---

## THE OPPORTUNITY

Established 2009. Sole operator retiring due to health. Genuine sale with full client handover.

**Premium "Walk On Dry" service** - immediate room use after cleaning (no 24hr drying time). Commands 30-40% premium over steam cleaning.

### FINANCIAL SNAPSHOT

| Metric | Value |
|--------|-------|
| Annual Revenue (capacity) | $120,000 - $150,000 |
| Current Run Rate | $80,000 - $100,000* |
| Average Job Value | $238 |
| Jobs Per Year | 500-680 |
| Work Days | 4 days/week typical |

*Reduced due to operator age (72) and health - significant upside for active buyer

### CLIENT BASE INCLUDED

- **995 total clients** in database
- **467 active clients** (serviced 2024-2025)
- **126 VIP repeat clients** (5+ services each)
- **53.6% repeat customer rate**
- Full contact database with service history

### TERRITORY COVERAGE

**Metro Adelaide:** Pasadena, Happy Valley, Belair, Henley Beach, Ridgehaven, Blackwood

**Fleurieu Peninsula:** Victor Harbor, Goolwa, Strathalbyn, Normanville (coastal holiday homes - premium clients)

**Yorke Peninsula:** Moonta, Maitland (established runs, no competition)

**Regional SA:** Murray Bridge, Balaklava, Clare (exclusive coverage)

### INCLUDED IN SALE

- ✅ Complete client database with 5 years history
- ✅ All equipment (Dry rotary scrubbing machines, solutions, accessories)
- ✅ Established phone number and business identity
- ✅ Training/handover from current operator (via video SOP)
- ✅ Regional "run" routes optimised over 15 years
- ✅ Relationships with hotels, B&Bs, churches, community centres

### IDEAL BUYER

- Owner-operator wanting established income from day one
- Semi-retired tradie wanting lifestyle business
- Couple seeking sea-change with built-in income
- Existing cleaner wanting premium clientele

### WHY SELL?

Operator (72) requires immediate medical retirement following successful brain surgery. Family-managed transition ensures smooth handover. First credible offer will be seriously considered.

---

**CONTACT:** Alpha Vector Technologies (Exit Advisory)  
**Email:** [Contact for details]  
**Reference:** Project Olympus

*Proof of funds required. NDA for full financials.*
