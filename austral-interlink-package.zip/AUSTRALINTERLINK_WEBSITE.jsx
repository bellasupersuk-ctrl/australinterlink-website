import React, { useState, useEffect } from 'react';

const AustralInterlinkWebsite = () => {
  const [scrolled, setScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-stone-50 text-stone-800 font-sans">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-sm shadow-sm' : 'bg-transparent'}`}>
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-700 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-lg">A</span>
            </div>
            <div>
              <div className="font-semibold text-stone-900 tracking-tight">Austral Interlink</div>
              <div className="text-xs text-stone-500 tracking-wide">INTERNATIONAL</div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm">
            <a href="#legacy" className="text-stone-600 hover:text-amber-700 transition-colors">Our Legacy</a>
            <a href="#methodology" className="text-stone-600 hover:text-amber-700 transition-colors">Methodology</a>
            <a href="#territory" className="text-stone-600 hover:text-amber-700 transition-colors">Service Areas</a>
            <a href="#contact" className="bg-amber-700 text-white px-4 py-2 rounded hover:bg-amber-800 transition-colors">Contact</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-stone-900 via-stone-800 to-amber-900"></div>
        <div className="absolute inset-0 opacity-20" style={{backgroundImage: 'url("data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%239C92AC" fill-opacity="0.1"%3E%3Cpath d="M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")'}}></div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <div className="inline-block mb-6 px-4 py-1 bg-amber-700/20 border border-amber-600/30 rounded-full">
            <span className="text-amber-300 text-sm tracking-widest uppercase">Est. 2009 · South Australia</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-light text-white mb-6 tracking-tight">
            Austral Interlink<br />
            <span className="font-semibold">International</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-stone-300 mb-8 font-light max-w-2xl mx-auto leading-relaxed">
            Premium carpet & upholstery care across South Australia. 
            Fifteen years of trusted service to discerning clients.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg px-6 py-4">
              <div className="text-3xl font-bold text-white">15</div>
              <div className="text-stone-400 text-sm">Years Operating</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg px-6 py-4">
              <div className="text-3xl font-bold text-white">995</div>
              <div className="text-stone-400 text-sm">Clients Served</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg px-6 py-4">
              <div className="text-3xl font-bold text-white">53.6%</div>
              <div className="text-stone-400 text-sm">Repeat Rate</div>
            </div>
          </div>
          
          <a href="#contact" className="inline-flex items-center gap-2 bg-amber-600 hover:bg-amber-700 text-white px-8 py-4 rounded-lg text-lg transition-colors">
            <span>Enquire Now</span>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>
        
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <svg className="w-6 h-6 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </section>

      {/* Legacy Section */}
      <section id="legacy" className="py-24 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <div className="text-amber-700 text-sm tracking-widest uppercase mb-4">Our Legacy</div>
              <h2 className="text-3xl md:text-4xl font-light text-stone-900 mb-6 leading-tight">
                Built on trust.<br />
                <span className="font-semibold">Sustained by results.</span>
              </h2>
              <div className="space-y-4 text-stone-600 leading-relaxed">
                <p>
                  Austral Interlink International was founded in 2009 by Sukninder Singh with a simple philosophy: 
                  deliver exceptional results and the clients will follow. Fifteen years later, that philosophy 
                  has built one of South Australia's most trusted carpet care practices.
                </p>
                <p>
                  Our client relationships span generations. We service homes where we cleaned the carpets 
                  before the children were born — and now clean those same carpets as the children leave for university. 
                  This isn't a transactional business. It's a trusted service built on consistency, reliability, 
                  and genuine care for our clients' homes.
                </p>
                <p>
                  From metropolitan Adelaide to the coastal retreats of Victor Harbor and the rural communities 
                  of the Yorke Peninsula, we've built a service network that reaches where others don't — and 
                  delivers quality that others can't match.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="bg-stone-100 rounded-2xl p-8">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-6 h-6 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <div className="font-semibold text-stone-900">Established 2009</div>
                      <div className="text-stone-600 text-sm">15 years of continuous operation</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-6 h-6 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                    </div>
                    <div>
                      <div className="font-semibold text-stone-900">995 Clients</div>
                      <div className="text-stone-600 text-sm">Comprehensive service database</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-6 h-6 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                      </svg>
                    </div>
                    <div>
                      <div className="font-semibold text-stone-900">53.6% Repeat Rate</div>
                      <div className="text-stone-600 text-sm">Industry benchmark: 40%</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <svg className="w-6 h-6 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <div className="font-semibold text-stone-900">$238 Average Job</div>
                      <div className="text-stone-600 text-sm">Premium positioning maintained</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Methodology Section */}
      <section id="methodology" className="py-24 bg-stone-100">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="text-amber-700 text-sm tracking-widest uppercase mb-4">Our Methodology</div>
            <h2 className="text-3xl md:text-4xl font-light text-stone-900 mb-4">
              Walk On Dry™
            </h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              Our proprietary low-moisture cleaning system delivers superior results 
              with immediate usability — no waiting 24 hours for carpets to dry.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-sm">
              <div className="w-14 h-14 bg-amber-700 rounded-xl flex items-center justify-center mb-6">
                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-stone-900 mb-3">Immediate Use</h3>
              <p className="text-stone-600">
                Carpets are ready to walk on within 1-2 hours, not 24. Perfect for families, 
                businesses, and rental turnovers.
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-sm">
              <div className="w-14 h-14 bg-amber-700 rounded-xl flex items-center justify-center mb-6">
                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-stone-900 mb-3">Fibre Safe</h3>
              <p className="text-stone-600">
                Low-moisture technology protects carpet fibres and backing from water damage, 
                mould, and the shrinkage that plagues steam cleaning.
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-sm">
              <div className="w-14 h-14 bg-amber-700 rounded-xl flex items-center justify-center mb-6">
                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-stone-900 mb-3">Deep Clean</h3>
              <p className="text-stone-600">
                Rotary scrubbing agitates fibres at the base, lifting embedded soil that 
                surface-only methods leave behind.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Territory Section */}
      <section id="territory" className="py-24 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="text-amber-700 text-sm tracking-widest uppercase mb-4">Service Territory</div>
            <h2 className="text-3xl md:text-4xl font-light text-stone-900 mb-4">
              Metropolitan & Regional Coverage
            </h2>
            <p className="text-stone-600 max-w-2xl mx-auto">
              We service where others won't. From the Adelaide Hills to the Fleurieu Coast 
              to the Yorke Peninsula, our routes are built for efficiency and reliability.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="border border-stone-200 rounded-xl p-8 hover:border-amber-300 hover:shadow-lg transition-all">
              <div className="text-amber-700 font-semibold mb-2">Metropolitan Adelaide</div>
              <div className="text-3xl font-bold text-stone-900 mb-4">328 <span className="text-lg font-normal text-stone-500">clients</span></div>
              <ul className="space-y-2 text-stone-600 text-sm">
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Happy Valley & Morphett Vale
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Blackwood & Belair
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Pasadena & Panorama
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Flagstaff Hill & Aberfoyle Park
                </li>
              </ul>
            </div>
            
            <div className="border border-stone-200 rounded-xl p-8 hover:border-amber-300 hover:shadow-lg transition-all">
              <div className="text-amber-700 font-semibold mb-2">Fleurieu Peninsula</div>
              <div className="text-3xl font-bold text-stone-900 mb-4">84 <span className="text-lg font-normal text-stone-500">clients</span></div>
              <ul className="space-y-2 text-stone-600 text-sm">
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Victor Harbor & Encounter Bay
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Goolwa & Goolwa Beach
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Strathalbyn & Myponga
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Normanville & Yankalilla
                </li>
              </ul>
            </div>
            
            <div className="border border-stone-200 rounded-xl p-8 hover:border-amber-300 hover:shadow-lg transition-all">
              <div className="text-amber-700 font-semibold mb-2">Yorke Peninsula</div>
              <div className="text-3xl font-bold text-stone-900 mb-4">24 <span className="text-lg font-normal text-stone-500">clients</span></div>
              <ul className="space-y-2 text-stone-600 text-sm">
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Maitland & Ardrossan
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Kadina & Moonta
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Crystal Brook
                </li>
                <li className="flex items-center gap-2">
                  <svg className="w-4 h-4 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  Wallaroo & Port Wakefield
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial / Trust Section */}
      <section className="py-24 bg-stone-900 text-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <svg className="w-12 h-12 text-amber-500 mx-auto mb-8" fill="currentColor" viewBox="0 0 24 24">
            <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
          </svg>
          <blockquote className="text-2xl md:text-3xl font-light leading-relaxed mb-8">
            "We've used Suki for over a decade. He knows our home, he knows our carpets, 
            and he always delivers. Finding someone you can trust with keys to your house is rare. 
            We found that with Austral Interlink."
          </blockquote>
          <div className="text-stone-400">
            — Long-term client, Victor Harbor
          </div>
        </div>
      </section>

      {/* Business Notice Section */}
      <section className="py-16 bg-amber-50 border-y border-amber-200">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="inline-block mb-4 px-4 py-1 bg-amber-100 border border-amber-300 rounded-full">
            <span className="text-amber-800 text-sm font-medium">Business Announcement</span>
          </div>
          <h3 className="text-2xl font-semibold text-stone-900 mb-4">
            Ownership Transition in Progress
          </h3>
          <p className="text-stone-700 max-w-2xl mx-auto leading-relaxed">
            After fifteen years of dedicated service to South Australian families and businesses, 
            founder Sukninder Singh is transitioning the business due to health considerations. 
            We are currently in discussions with established operators to ensure continuity of 
            service for our valued clients. Industry professionals with enquiries regarding 
            acquisition opportunities may contact us directly.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16">
            <div>
              <div className="text-amber-700 text-sm tracking-widest uppercase mb-4">Contact</div>
              <h2 className="text-3xl md:text-4xl font-light text-stone-900 mb-6">
                Get in touch
              </h2>
              <p className="text-stone-600 mb-8">
                For service enquiries or business discussions, please contact us directly. 
                We respond to all enquiries within 24 hours.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-semibold text-stone-900">Phone</div>
                    <div className="text-stone-600">0400 XXX XXX</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-semibold text-stone-900">Email</div>
                    <div className="text-stone-600">contact@australinterlink.com</div>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-amber-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                  </div>
                  <div>
                    <div className="font-semibold text-stone-900">ABN</div>
                    <div className="text-stone-600">XX XXX XXX XXX</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-stone-50 rounded-2xl p-8">
              <h3 className="text-xl font-semibold text-stone-900 mb-6">Send a message</h3>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-1">Name</label>
                  <input type="text" className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-1">Email</label>
                  <input type="email" className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-1">Enquiry Type</label>
                  <select className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors bg-white">
                    <option>Service Enquiry</option>
                    <option>Business Enquiry</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-1">Message</label>
                  <textarea rows={4} className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-colors resize-none"></textarea>
                </div>
                <button type="submit" className="w-full bg-amber-700 hover:bg-amber-800 text-white py-3 rounded-lg font-medium transition-colors">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-stone-900 text-stone-400 py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-700 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">A</span>
              </div>
              <div>
                <div className="font-semibold text-white tracking-tight">Austral Interlink International</div>
                <div className="text-xs text-stone-500">Premium Carpet & Upholstery Care</div>
              </div>
            </div>
            <div className="text-sm text-center md:text-right">
              <div>© 2009–2025 Austral Interlink International. All rights reserved.</div>
              <div className="text-stone-500 mt-1">ABN XX XXX XXX XXX · South Australia</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default AustralInterlinkWebsite;
