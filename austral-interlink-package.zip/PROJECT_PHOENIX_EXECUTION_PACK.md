# PROJECT PHOENIX — EXECUTION PACK
## Six Bespoke Emails for Immediate Deployment
### December 26, 2025

---

# INSTRUCTIONS FOR USE

**Sequence:**
1. Send all six emails between 6:30am - 7:00am
2. Send follow-up texts at 9:00am to anyone who hasn't responded
3. Begin phone calls at 10:00am in priority order

**Technical Notes:**
- Send from Dad's personal email (establishes authenticity)
- BCC yourself on all emails (tracks delivery)
- Subject lines are crafted to avoid spam filters and compel opens
- Each email is designed to be forwarded to a spouse/partner for discussion

---

# EMAIL 1: JAMIE SIMPSON — SUPER CLEAN CARPET CARE
## Territory: Fleurieu Peninsula (84 clients)
## Estimated Value: $40,000 - $50,000

**To:** jamie@supercleancarpetcare.com.au  
**Subject:** Your territory. My clients. One conversation.

---

Jamie,

You don't know me, but you know my work.

I'm Suki Singh. I've been running Austral Interlink International for fifteen years — low-moisture rotary cleaning across Adelaide and the regions. Last month I had brain surgery. I'm 72. The doctor's told me to stop, and for once in my life, I'm going to listen.

I'm writing to you specifically because I've spent the last week thinking about what happens to my clients. Not the business — the people. Mrs Blanchard in Victor Harbor who's been with me for ten jobs. Colleen Mccalum on Grantley Ave. Daphne Neville in Goolwa. The Shillers in McCracken who leave their back door unlocked because they trust me in their home.

I have 84 active clients on the Fleurieu Peninsula. They're yours if you want them.

**Here's why I'm calling you and not running an ad:**

I looked at who services the South Coast properly. Not the steam guys who leave carpets wet for 24 hours. Not the franchise operators running in from Adelaide with no local presence. You. You're based in Encounter Bay. You run encapsulation — same methodology I use. Your reviews say the same things my clients say about me: "prompt, professional, quality work."

If I hand my Fleurieu clients to you, they won't know the difference. Same dry carpets. Same day-of-service results. Just a different face at the door — and I'll make the introduction personally if you want.

**What I'm not doing:**

I'm not going to a broker. I'm not listing this on Gumtree where every cowboy with a rented machine will lowball me. And I'm not handing my coastal clients to Jim's so they can drop some franchisee from Adelaide into your backyard.

I'd rather you had them.

**The numbers:**

- 84 active clients (serviced 2024-2025)
- Average job value: $240
- Platinum clients include 10 accounts averaging $300+ per job
- Geographic concentration: Victor Harbor, Goolwa, McCracken, Normanville, Strathalbyn
- Repeat rate: 58% (these people rebook without being asked)

I'm asking $45,000 for the Fleurieu book. That's roughly what you'd spend on marketing over three years to acquire half as many clients who aren't pre-sold on quality service.

**What happens next:**

If you're interested, call me. Not email — call. I want to hear your voice and know you're the right person to look after these people.

If I don't hear from you by end of business Friday, I'll assume you're not interested and move to my second option. No hard feelings.

But I hope you call.

Suki Singh  
**0400 XXX XXX**  
Austral Interlink International  
ABN: XX XXX XXX XXX

P.S. — I know you're probably wondering why I'm not asking more. The truth is: I've had a good run. I built this from nothing, one cold call at a time. The money matters, but not as much as knowing Mrs Blanchard won't be left wondering why I stopped showing up. You're the right operator for this. The price reflects my confidence in that.

---

# EMAIL 2: CAROLYN & IAN — YORKE PENINSULA CARPET CLEANING
## Territory: Yorke Peninsula (24 clients)
## Estimated Value: $20,000 - $30,000

**To:** ypcarpet@gmail.com  
**Subject:** The Maitland run — before anyone else sees it

---

Carolyn,

I'll get straight to it.

I'm Suki Singh. I've been cleaning carpets across South Australia for fifteen years. I've just had brain surgery and I need to retire — immediately, not "in six months when I find a buyer."

I have a regional run on the Yorke Peninsula that I'm offering to you before I offer it to anyone else. Here's why:

**You're the only operator who makes sense for this.**

My Yorke clients are in Maitland, Crystal Brook, Kadina, and Ardrossan. That's 150km from Adelaide. No metro cleaner wants that drive. They'd have to dedicate an entire day to service three or four jobs and lose money on fuel.

But you're already there. You're already running the Copper Coast. These clients are 20 minutes from your existing routes, not two hours.

If you don't take this run, I have two choices: sell it to someone who'll service it badly, or let it die. I'd rather you had it.

**The specifics:**

- 24 active clients across the Yorke Peninsula
- High-value accounts: Belinda Wunder in Maitland ($374 average job), Kathryn Crouch in Crystal Brook ($297), Lillian James in Kadina
- Service notes included: pet situations, stain histories, access arrangements
- Average job value: $220

I'm asking $25,000 for the Yorke book. That's what you'd pay a marketing company to get you half as many leads who've never heard of you. These people already trust a carpet cleaner — they just need to trust a new face.

**Why the urgency:**

I have an Adelaide operator (Jim's Group) looking at my entire book. If Bill Cobanoglu decides he wants to seed a Yorke Peninsula franchise, he'll take these clients and drop someone into your market with a pre-built customer base.

I don't want that. I've seen what happens when the franchises move into a region — they undercut on price until the local operators give up, then they raise prices once there's no competition.

You and Ian have built something on the Yorke Peninsula. I'd rather strengthen that than undermine it.

**Next step:**

Call me today. I'm not asking for a decision on the phone — just a conversation about whether this makes sense for you.

If I don't hear from you by tomorrow, I'll have to move forward with other options.

Suki Singh  
**0400 XXX XXX**  
Austral Interlink International

P.S. — The run includes a client in Maitland who's booked me eight times and pays $374 average. She's due for another clean in February. That's one job that nearly pays for a month of your marketing budget. Just one.

---

# EMAIL 3: MAX WRIGHT — THE CARPET DOCTOR
## Territory: Adelaide Hills / Southern Metro (50+ clients)
## Estimated Value: $20,000 - $25,000

**To:** max@thecarpetdoctor.com.au  
**Subject:** Blackwood, Belair, Pasadena — your neighbours, my clients

---

Max,

We've been working the same hills for years and never crossed paths. I'm Suki Singh — Austral Interlink International. You might have seen my van around Blackwood.

I'm writing because I've just had brain surgery and I need to stop. Not wind down. Stop. The doctors weren't negotiating.

I have a cluster of clients in Blackwood, Belair, Pasadena, and Upper Sturt that I want to offer you before I do anything else.

**Here's the logic:**

You're "The Carpet Doctor." You're based in the hills. You've been doing this since the 90s — long enough to know that windshield time is the enemy. Every minute you spend driving to a job in Seaford is a minute you're not earning.

My hills clients are your neighbours. You drive past their houses on your way to the shops. Adding them to your existing runs costs you nothing in travel and everything in margin.

I'm not offering you a "business opportunity." I'm offering you 50+ warm, loyal clients who are five minutes from where you already work.

**The repair angle:**

You do stretching, patching, and repairs. I don't. These carpets have been cleaned by me for 15 years. Many of them are ready for the services only you can provide. You'll make double what I did on these clients because you can upsell the repair work.

I can't. You can.

**The numbers:**

- 50+ active clients in Blackwood, Belair, Pasadena, Upper Sturt
- Average job value: $180
- High-value accounts include Sue Rodgers (Blackwood, $257), Mrs Ann Solomon (Pasadena, $173)
- Detailed service notes: stain types, pet situations, access arrangements

I'm asking $20,000 for this cluster. It's priced to move because I don't have time to negotiate for weeks. I need to be done.

**What I'm not doing:**

I'm not listing this publicly. I'm not going to a broker. And I'm not handing my hills clients to some franchise who'll send a different 23-year-old to every job.

You've been doing this for 30 years. You know what quality means. That's why I'm calling you.

**Next step:**

Call me. Let's talk about whether this makes sense for your operation. If you're winding down yourself, I understand — just let me know and I'll move on with no hard feelings.

But if you want to add zero-travel, high-margin work to your existing runs, this is the easiest money you'll ever make.

Suki Singh  
**0400 XXX XXX**  
Austral Interlink International

P.S. — I looked you up. "First Aid for Carpets." I like that. My clients are going to be in good hands with someone who thinks like that.

---

# EMAIL 4: BILL COBANOGLU — JIM'S CLEANING GROUP SA
## Territory: Metro Adelaide (328 clients) or Whole Book (467 clients)
## Estimated Value: $30,000 - $85,000 (depending on scope)

**To:** bill@jimslaundryservices.com.au  
**Subject:** 467 clients. Adelaide South. Ready to seed.

---

Bill,

I'll be direct. I know you're busy, and I know what you're looking for.

I'm Suki Singh. I've run Austral Interlink International for fifteen years — premium carpet and upholstery cleaning across Adelaide and the regions. I've just had brain surgery, and I need to exit immediately.

I have 467 active clients. 328 of them are in metropolitan Adelaide, concentrated in Happy Valley, Morphett Vale, Pasadena, Blackwood, and the southern suburbs. The rest are in regional clusters on the Fleurieu and Yorke Peninsulas.

I'm contacting you because this client base is exactly what Jim's needs to seed new franchise territories or fill gaps in existing ones.

**Here's what I understand about your business:**

You don't clean carpets. You sell territories. You recruit franchisees. And the hardest part of that job is giving a new franchisee enough work to survive their first year.

I'm handing you a ready-made income stream for your next recruit in Adelaide South. Or your next three recruits, if you want to split it.

**The numbers:**

- 467 active clients (serviced 2024-2025)
- $80,000+ annual revenue at current (reduced) capacity
- $120,000+ potential at full operational capacity
- 53.6% repeat rate — these clients rebook without prompting
- Average job value: $238 (premium pricing, not discount)

**What I'm offering:**

**Option A — Metro Only:** 328 clients in Adelaide South for $35,000. Perfect for seeding a Happy Valley or Morphett Vale territory.

**Option B — Whole Book:** All 467 clients across Metro, Fleurieu, and Yorke for $75,000. You get the regional runs as bonuses to offer experienced franchisees who want to expand their footprint.

**Why the price:**

I'm not asking 2x earnings. I don't have time for six months of due diligence. I need settlement this week. The discount reflects that urgency, not the quality of the asset.

**What happens if you pass:**

I've already contacted the regional independents about the Fleurieu and Yorke runs. If you want the whole book, you need to move before I parcel it out. Once Jamie Simpson in Victor Harbor takes the coastal clients and Carolyn in Kadina takes the Yorke run, all that's left for Jim's is the scraps.

I'd rather do one deal with you than four deals with four different operators. But I'll do whatever gets this closed by Friday.

**Next step:**

Call me or have someone call me today. I'm happy to meet at your office, send the client list under NDA, or structure this however Jim's needs to move quickly.

Suki Singh  
**0400 XXX XXX**  
Austral Interlink International  
ABN: XX XXX XXX XXX

P.S. — I know Peter Karaoglanis has been running Jim's Carpet Cleaning in Happy Valley for 20 years. If he wants to expand his territory, I'm happy to talk directly with him. But I figured I'd start with you.

---

# EMAIL 5: ALEX OAKLEY — NYP CLEANING SERVICE
## Territory: Yorke Peninsula (backup buyer)
## Estimated Value: $20,000 - $25,000

**To:** nypcleaning@outlook.com.au  
**Subject:** Carpet clients on the Yorke — family business to family business

---

Alex,

I'll keep this short because I know you've got a business to run.

I'm Suki Singh. I've been cleaning carpets across South Australia for fifteen years. I've just had brain surgery and I need to retire — not in six months, now.

I have a run on the Yorke Peninsula that I need to place with someone who'll look after the clients. When I looked at who operates on the peninsula, I found two names: Yorke Peninsula Carpet Cleaning in Kadina, and your family's business in Moonta Bay.

I'm reaching out to both of you because one of you should have these clients — and I'd rather it be a local family business than some franchise operator from Adelaide who doesn't know the area.

**What I've got:**

- 24 active clients across Maitland, Crystal Brook, Kadina, Ardrossan, and Moonta
- High-value accounts: Belinda Wunder (Maitland, $374 avg), Kathryn Crouch (Crystal Brook, $297)
- Average job value: $220
- These clients have been with me for years — they're loyal, they pay on time, they don't haggle

**Why this might work for you:**

I know NYP does general cleaning, lawn mowing, and a range of services. Carpet cleaning might not be your core business. But these clients already need their carpets cleaned — they've been paying me to do it for years.

If you can service them (or partner with someone who can), you've got a built-in referral network for your other services. Everyone who needs their carpets cleaned also needs their windows done, their lawns mowed, their gutters cleared.

I'm asking $25,000 for the Yorke book. But I'm open to a conversation about what makes sense for your operation.

**The timing:**

I've already contacted Carolyn at Yorke Peninsula Carpet Cleaning. If she takes this, it won't be available. I wanted to give you the option before that happens.

Call me if you're interested. If carpet cleaning isn't your thing, no hard feelings — just let me know and I'll move on.

Suki Singh  
**0400 XXX XXX**  
Austral Interlink International

P.S. — I saw your family's been in business since 1983. I respect that. Building something that lasts multiple generations is rare. I hope this helps you keep building.

---

# EMAIL 6: MURRAY LANDS CLEANING SERVICE
## Territory: Murray Bridge (small cluster)
## Estimated Value: $3,000 - $5,000 (or whole book fallback)

**To:** tdhaywood@bigpond.com  
**Subject:** Small opportunity — Murray Bridge carpet clients

---

G'day,

I'm Suki Singh from Austral Interlink International. I've been running carpet and upholstery cleaning across South Australia for fifteen years.

I've just had some health issues that mean I need to retire, and I'm reaching out to a few operators in different regions about taking on my client base.

I only have a small cluster in Murray Bridge — three active clients — so this might not be worth your time. But I wanted to offer it to a local operator before I let it go.

If you're interested in picking up a few carpet cleaning clients in the Murray Bridge area, give me a call. I'm not looking for much — just enough to make it worth my time to hand over the details properly.

If you're not doing carpet work anymore, or if three clients isn't worth the conversation, no worries at all. Just let me know.

Suki Singh  
**0400 XXX XXX**

---

# FOLLOW-UP TEXT TEMPLATES
## Send at 9:00am to anyone who hasn't responded

---

**JAMIE:**
> Jamie — Suki Singh here. Sent you an email this morning about my Fleurieu clients. 84 accounts in Victor Harbor, Goolwa, McCracken. Worth a 5-minute call. 0400 XXX XXX

**CAROLYN:**
> Carolyn — Suki Singh. Sent you an email about my Yorke Peninsula run. 24 clients in Maitland, Crystal Brook, Kadina. Call me when you've got 5 mins. 0400 XXX XXX

**MAX:**
> Max — Suki Singh. Sent you something about my Blackwood and Belair clients. Neighbours to you. Worth a quick chat. 0400 XXX XXX

**BILL:**
> Bill — Suki Singh, Austral Interlink. 467 active carpet clients in Adelaide South. Looking to move this week. Worth a call. 0400 XXX XXX

**ALEX:**
> Alex — Suki Singh. Sent you an email about my Yorke Peninsula carpet clients. Family business opportunity. Give me a call if interested. 0400 XXX XXX

---

# PRIORITY CALL ORDER (10:00am onwards)

| Priority | Name | Phone | Why First |
|----------|------|-------|-----------|
| 1 | Jamie Simpson | 0488 522 520 | Highest value, most motivated, technology match |
| 2 | Carolyn & Ian | 0428 858 759 | Monopoly buyer, no alternative for Yorke |
| 3 | Bill Cobanoglu | 131 546 | Corporate buyer, has cash, can move fast |
| 4 | Max Wright | 0409 692 003 | Quick decision maker, knows the value |
| 5 | Alex Oakley | 0417 808 512 | Backup for Yorke, cross-sell opportunity |
| 6 | Murray Lands | (08) 8532 6766 | Low priority, small cluster |

---

# END EXECUTION PACK
