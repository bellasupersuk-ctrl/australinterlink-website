# PROJECT PHOENIX: WEBSITE ELEVATION DIRECTIVE

## CONTEXT

You are elevating australinterlink.com — a website for a 15-year carpet cleaning business in South Australia currently undergoing ownership transition. The site exists. It works. But it needs to become **undeniably institutional** — the kind of digital presence that makes sophisticated buyers (regional carpet cleaning operators, Jim's Group franchisors, and industry consolidators) take this acquisition opportunity seriously.

This is not a consumer-facing marketing site. This is a **credibility instrument** designed to convert one of six pre-qualified buyers into a signed deal within 72 hours.

---

## THE ASSET

**Austral Interlink International**
- ABN: 50 353 196 500
- Founder: Sukninder Singh
- Established: 2009 (15 years continuous operation)
- Clients: 995 total in database
- Repeat Rate: 53.6% (industry benchmark: 40%)
- Average Job Value: $238
- Methodology: Walk On Dry™ (low-moisture/encapsulation)

**Territory Coverage:**
- Metropolitan Adelaide: 328 clients (Happy Valley, Morphett Vale, Blackwood, Belair, Pasadena, Panorama, Flagstaff Hill, Aberfoyle Park)
- Fleurieu Peninsula: 84 clients (Victor Harbor, Encounter Bay, Goolwa, Strathalbyn, Myponga, Normanville, Yankalilla)
- Yorke Peninsula: 24 clients (Maitland, Ardrossan, Kadina, Moonta, Crystal Brook, Wallaroo, Port Wakefield)
- Adelaide Hills: 50+ clients
- Murray Lands: Small cluster

**Sale Context:**
Founder requiring medical retirement (brain surgery). Business transition, not distress sale. Asking $85,000-$115,000 depending on territory split configuration. Pre-qualified buyers already contacted via direct email campaign.

---

## TARGET AUDIENCE (The Only People Who Matter)

1. **Jamie Simpson** — Super Clean, Encounter Bay. Encapsulation specialist. Fleurieu competitor. Territorial.
2. **Carolyn/Ian** — Yorke Peninsula Carpet Cleaning, Maitland. Regional monopoly holders. Protection-motivated.
3. **Max Wright** — The Carpet Doctor, Adelaide Hills. 30+ years experience. Repair/restoration focus. Efficiency-driven.
4. **Bill Cobanoglu** — Jim's Carpet Cleaning regional franchisor. Corporate buyer. Territory-seeding motivation.
5. **Alex Oakley** — NYP Cleaning Services, Yorke Peninsula. Family business. Multi-service operator.

These are **trade professionals**, not consumers. They understand equipment, margins, route density, and client lifetime value. They will scrutinise this site for legitimacy markers, not pretty graphics.

---

## ELEVATION OBJECTIVES

### 1. INSTITUTIONAL GRAVITAS
The site must feel like it was built by a business broker or M&A advisor, not a small business owner. Think private equity pitch deck translated to web. No startup aesthetics. No template smell. No stock photos.

**Specific requirements:**
- Typography that signals heritage and permanence (serifs for headlines, clean sans for body)
- Colour palette of warm neutrals (stone, cream, amber gold) — not corporate blue, not tech purple
- Whitespace that breathes confidence, not emptiness
- Data visualisation where appropriate (territory maps, metrics)
- Zero visual clutter

### 2. CREDIBILITY INFRASTRUCTURE
Every element must answer the buyer's unspoken question: "Is this real?"

**Required credibility markers:**
- ABN prominently displayed (verifiable via ABR lookup)
- Specific client counts by territory (not rounded numbers)
- Repeat rate with industry benchmark comparison
- Years of continuous operation
- Methodology explanation that demonstrates technical competence
- Founder name (Sukninder Singh) — real person, verifiable
- Business transition notice that explains the "why" without triggering distress signals

### 3. CONVERSION ARCHITECTURE
The site has ONE job: make qualified buyers call.

**Conversion requirements:**
- Phone number visible without scrolling on every viewport
- Contact form that captures enquiry type (Service vs Business Enquiry)
- "Business Announcement" section that signals opportunity to industry insiders
- Clear call-to-action language: "Enquire Now" not "Learn More"
- No friction points — no chat widgets, no pop-ups, no newsletter captures

### 4. INFORMATION HIERARCHY
Buyers need specific information in a specific order:

1. **Immediate:** What is this? (Premium carpet care, established 2009, South Australia)
2. **Validation:** Is this legitimate? (ABN, client count, repeat rate, methodology)
3. **Scope:** What's the territory? (Three regions with specific suburbs and client counts)
4. **Opportunity:** What's happening? (Ownership transition, business enquiries welcome)
5. **Action:** How do I engage? (Phone, email, form)

### 5. TECHNICAL EXCELLENCE
The site must load instantly and render perfectly.

**Technical requirements:**
- Single HTML file (no build process required)
- Embedded CSS (no external dependencies except fonts)
- Vanilla JavaScript only (no frameworks)
- Mobile-responsive without breakage
- Google Fonts loaded via preconnect
- Semantic HTML for accessibility
- No console errors

---

## DESIGN DIRECTION

### Typography
- **Display/Headlines:** Cormorant Garamond or similar serif — elegant, established, not decorative
- **Body:** Inter or similar clean sans — readable, professional, not trendy
- **Hierarchy:** Clear size/weight differentiation between H1 > H2 > H3 > body

### Colour Palette
```
--color-cream: #FAF8F5 (background)
--color-stone: #1C1917 (primary text)
--color-stone-600: #57534E (secondary text)
--color-amber: #92400E (accent/links)
--color-gold: #A16207 (hover states)
```

### Visual Language
- Geometric precision, not organic shapes
- Subtle texture (noise overlay on dark sections)
- Gold/amber accents used sparingly for emphasis
- Icons: simple line style, not filled, not playful
- No photos — this is a B2B credibility piece, not a consumer brochure

### Motion
- Subtle fade-in animations on scroll (not bouncy, not playful)
- Smooth scroll behaviour
- Hover state transitions (0.2s ease)
- No parallax, no particle effects, no "wow" moments

---

## SECTION REQUIREMENTS

### Hero
- Full viewport height
- Dark background (stone/charcoal) with subtle noise texture
- Badge: "Established 2009 · South Australia"
- Headline: "Austral Interlink International" (two lines, second line bolder)
- Subhead: One sentence positioning statement
- Three stats in horizontal row: Years (15), Clients (995), Repeat Rate (53.6%)
- Primary CTA: "Enquire Now" button
- Scroll indicator at bottom

### Legacy Section
- White background
- Two-column layout: narrative left, metrics right
- Story: founding philosophy, client relationships spanning generations, territorial reach
- Metrics panel: 4 items with icons (Established 2009, 995 Clients, 53.6% Repeat Rate, $238 Avg Job)

### Methodology Section
- Dark background (stone) with noise texture
- "Walk On Dry™" as section title
- Brief intro paragraph
- Three cards: Immediate Use, Fibre Safe, Deep Clean
- Each card: icon, title, description
- Technical enough to signal competence to trade buyers

### Territory Section
- White background
- Centered header with intro text
- Three territory cards: Metro (328), Fleurieu (84), Yorke (24)
- Each card: region name, client count, suburb list
- Hover effect: border highlight, subtle shadow lift

### Testimonial Section
- Cream/neutral background
- Large quotation mark icon
- Single testimonial: "We've used Suki for over a decade..." 
- Attribution: "— Long-term client, Victor Harbor"
- Understated — not the focus, just social proof

### Business Notice Section
- Amber/gold tinted background
- "Business Announcement" badge
- "Ownership Transition in Progress" headline
- Brief explanation: founder transitioning due to health, seeking established operators, continuity focus
- This is the **signal** to buyers that opportunity exists

### Contact Section
- White background
- Two-column: info left, form right
- Contact methods: Phone, Email, ABN (with icons)
- Form fields: Name, Email, Enquiry Type (dropdown), Message
- Submit button: full-width, dark background

### Footer
- Dark background
- Logo mark + business name
- Copyright: "© 2009–2025 Austral Interlink International"
- ABN displayed

---

## SPECIFIC COPY REQUIREMENTS

### Headlines (use exactly or improve minimally)
- Hero: "Austral Interlink International"
- Legacy: "Built on trust. Sustained by results."
- Methodology: "Walk On Dry™"
- Territory: "Metropolitan & Regional Coverage"
- Notice: "Ownership Transition in Progress"
- Contact: "Get in touch"

### Key Statistics (must appear)
- 15 years operating
- 995 clients served
- 53.6% repeat rate (with "Industry benchmark: 40%" qualifier)
- $238 average job value
- 328 Metro clients, 84 Fleurieu clients, 24 Yorke clients

### Business Transition Copy (tone is critical)
Must communicate: retirement transition (not failure), seeking quality operators (not desperate sale), continuity for clients (professionalism), industry professionals welcome (signalling to right audience).

Avoid: urgency language, discount signals, distress indicators, "must sell" framing.

---

## OUTPUT REQUIREMENTS

Deliver a **single, complete HTML file** that:

1. Renders perfectly at all viewport sizes (mobile, tablet, desktop)
2. Loads in under 2 seconds on 3G
3. Contains all CSS inline (within `<style>` tags)
4. Contains all JavaScript inline (within `<script>` tags)
5. Uses only Google Fonts as external dependency
6. Passes W3C HTML validation
7. Scores 90+ on Lighthouse performance
8. Contains zero placeholder content — everything is final copy
9. Includes proper meta tags (title, description, viewport)
10. Includes Open Graph tags for social sharing

---

## WHAT SUCCESS LOOKS LIKE

When Jamie Simpson clicks the link in his email and lands on this site, his internal monologue should be:

"This is real. This isn't some desperate bloke trying to offload a failing run. This is a proper business with a proper database. If I don't move on this, Bill from Jim's will snap it up and I'll have a franchisee in my territory within six months. I need to call this number today."

That's the elevation. That's the stratosphere.

---

## EXECUTE NOW

Build the complete HTML file. No commentary. No explanations. Just the code.
