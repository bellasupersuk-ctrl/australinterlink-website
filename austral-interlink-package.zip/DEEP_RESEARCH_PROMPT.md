# DEEP RESEARCH BRIEF: ACCELERATED ASSET DISPOSAL - PROJECT OLYMPUS

## CLASSIFICATION: TIME-CRITICAL TRANSACTION EXECUTION
## DEADLINE: 24 HOURS FROM INITIATION
## ASSET: Austral Interlink International (AII) - SA Carpet Cleaning Business

---

## 1. MISSION OBJECTIVE

Execute a strategic buyer identification and outreach campaign to secure a Letter of Intent (LOI) or verbal commitment for the acquisition of AII within 24 hours. This is a distressed sale driven by vendor health emergency requiring immediate retirement.

---

## 2. ASSET PROFILE (VERIFIED DATA)

### Financial Metrics
- **Annual Revenue:** $80,000 - $100,000 (current reduced capacity)
- **Revenue at Full Capacity:** $120,000 - $150,000
- **Average Job Value:** $238
- **Jobs per Annum:** 500-680
- **Seller's Discretionary Earnings (SDE):** ~$80,000

### Client Base
- **Total Clients:** 995
- **Active Clients (2024-2025):** 467
- **VIP Repeat Clients (5+ services):** 126
- **Repeat Rate:** 53.6%

### Geographic Coverage
- Metro Adelaide: 75% of revenue (Pasadena, Happy Valley, Belair, Henley Beach, Ridgehaven)
- Fleurieu Peninsula: Victor Harbor, Goolwa, Strathalbyn, Normanville
- Yorke Peninsula: Moonta, Maitland, Kadina
- Regional SA: Murray Bridge, Balaklava, Clare, Peterborough

### Competitive Moat
- Premium "Walk On Dry" rotary scrubbing (immediate room use vs 24hr steam drying)
- 15-year established relationships with HNW coastal property owners
- Exclusive regional runs with no viable competition
- Institutional clients: hotels, B&Bs, churches, community centres

### Asking Price
- **Listed:** $85,000
- **Floor:** $75,000
- **Valuation Basis:** 1.0x - 1.2x SDE (distressed sale multiple)

---

## 3. RESEARCH REQUIREMENTS

### 3.1 BUYER UNIVERSE IDENTIFICATION

#### Tier 1: Strategic Acquirers (Highest Probability - Contact First)
Research and identify:

1. **Existing Adelaide Carpet Cleaning Operators**
   - Independent operators looking to expand territory
   - Operators in adjacent suburbs wanting Fleurieu/Yorke Peninsula access
   - Search: Adelaide carpet cleaning businesses, owner names, contact details
   - Platforms: Google Maps listings, Yellow Pages, Hipages, ServiceSeeking

2. **Jim's Cleaning / Franchise Operators Seeking Independence**
   - Jim's Cleaning franchisees in Adelaide metro who may want to exit franchise model
   - Other franchise operators (Electrodry, Chem-Dry, etc.) seeking independent operation
   - Research franchise dissatisfaction forums, business sale enquiry patterns

3. **Adjacent Service Providers**
   - Carpet retailers (Carpet Court, Carpet Call) who cross-sell cleaning
   - Flooring installers wanting recurring revenue stream
   - General cleaning businesses wanting to add carpet specialty
   - End-of-lease cleaning operators wanting to expand services

#### Tier 2: Financial Buyers
4. **Lifestyle Buyers**
   - Semi-retired tradies seeking low-physical-demand business
   - Sea-changers relocating to Fleurieu Peninsula wanting income
   - Research: Adelaide early retirement forums, Fleurieu Peninsula community groups

5. **Immigrant Entrepreneur Market**
   - New Australians seeking established business with training
   - Business migration visa holders needing operational business
   - Research: Migration agent networks, multicultural business associations SA

#### Tier 3: Platform Buyers
6. **Business Brokers with Active Buyer Lists**
   - Identify Adelaide-based business brokers specialising in service businesses
   - Research which brokers have recently sold cleaning/service businesses
   - Brokers: Klemms, Xcllusive, LINK Business, Transact

### 3.2 CHANNEL RESEARCH

Identify and provide direct links/contact methods for:

1. **Online Marketplaces (Immediate Listing)**
   - Seek Business (seekbusiness.com.au) - listing process, costs, featured options
   - BusinessesForSale.com.au - process, audience demographics
   - Gumtree Commercial - optimal category, timing for visibility
   - Facebook Marketplace & Groups - identify specific Adelaide business sale groups

2. **Industry Networks**
   - Carpet Cleaning Association of Australia - member directories, forums
   - Cleaning contractors associations SA
   - Small Business SA networks

3. **Local Media**
   - Adelaide Advertiser classifieds - business for sale section
   - Messenger newspapers (local suburban reach)
   - Victor Harbor Times / Fleurieu newspapers (coastal buyer reach)

4. **Direct Outreach Databases**
   - ABN Lookup for cleaning businesses in SA
   - LinkedIn search strategies for cleaning business owners Adelaide

### 3.3 COMPETITIVE INTELLIGENCE

Research and report:
1. Recent carpet cleaning business sales in Australia (comparable transactions)
2. Current carpet cleaning businesses for sale (competitive listings)
3. Valuation benchmarks for cleaning service businesses
4. Common deal structures for service business sales

### 3.4 RAPID DUE DILIGENCE PACKAGE

Identify what buyers will request and prepare responses:
1. Standard due diligence checklist for service business acquisition
2. Common buyer objections for owner-dependent businesses
3. Transition/training expectations in cleaning business sales
4. Non-compete and handover period norms

---

## 4. EXECUTION STRATEGY REQUIRED

### Phase 1: Hours 0-4 (Immediate)
- Prioritised list of 20 specific potential buyers with contact details
- Optimal listing text for each platform
- Outreach message templates (email, phone script, LinkedIn)

### Phase 2: Hours 4-12 (Active Outreach)
- Broker engagement strategy
- Social media posting schedule
- Direct contact prioritisation matrix

### Phase 3: Hours 12-24 (Conversion)
- Negotiation parameters and walk-away points
- LOI template for rapid commitment
- Deposit and settlement structure recommendations

---

## 5. OUTPUT FORMAT REQUIRED

### Deliverable 1: Buyer Target List
| Rank | Buyer Name/Company | Type | Contact Method | Rationale | Approach Script |
|------|-------------------|------|----------------|-----------|-----------------|

### Deliverable 2: Channel Execution Checklist
| Platform | URL | Cost | Time to Post | Expected Response Time | Priority |
|----------|-----|------|--------------|----------------------|----------|

### Deliverable 3: Outreach Templates
- Cold call script (30 seconds)
- Email template (subject line + body)
- LinkedIn message
- Broker pitch

### Deliverable 4: Negotiation Framework
- Opening position
- Concession ladder
- Walk-away triggers
- Closing techniques for urgency

### Deliverable 5: Risk Mitigation
- Key objection responses
- Deal-breaker scenarios and solutions
- Backup strategies if primary channels fail

---

## 6. CONSTRAINTS & PARAMETERS

- **Budget for listings:** Up to $500 total
- **Vendor availability:** Limited (recovering from surgery) - son managing sale
- **Geographic focus:** Adelaide metro and SA regional buyers preferred
- **Timeline:** Non-negotiable 24-hour window for initial commitment
- **Minimum acceptable price:** $75,000
- **Preferred structure:** Cash on completion, 2-week handover included
- **Non-compete:** Vendor will sign standard non-compete (not a barrier)

---

## 7. SUCCESS CRITERIA

1. **Minimum:** 3 qualified buyer enquiries within 12 hours
2. **Target:** 1 verbal offer within 18 hours  
3. **Optimal:** Signed LOI or deposit within 24 hours

---

## 8. CONTEXT FOR URGENCY

The vendor (72) has just undergone brain surgery and is in home recovery. Continued operation is medically impossible. Each day of delay:
- Risks client attrition as regular service schedules are missed
- Increases key-man risk as relationships cool
- Reduces asset value as the "going concern" narrative weakens

This is a genuine distressed sale where speed of execution is weighted equally with price optimisation.

---

## 9. RESEARCH INITIATION COMMAND

Begin systematic research across all identified buyer categories and channels. Prioritise actionable intelligence over comprehensive analysis. Every output should answer: "What specific action can be taken in the next 60 minutes based on this information?"

Focus on:
1. Names and phone numbers of potential buyers
2. Exact URLs and posting steps for each platform
3. Specific scripts and templates ready for immediate use
4. Decision trees for rapid response to enquiries

Time is the enemy. Execute with precision.

---

**END BRIEF**
